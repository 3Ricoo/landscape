Version 0.1212
--------------

Change dependencies to the GPmat toolbox.

Version 0.1211
--------------

Minor bug fix in demBarenco1.m

Version 0.121
-------------

Minor fixes of the code for dealing with white noise handling in multiKern.

Version 0.12
------------

Release with first draft of journal paper.

Version 0.111
-------------

Mistakenly the technical noise was not being added in the kernel computation, change to gpsimUpdateKernels.m.

Version 0.11
------------

Release with scripts to recreate results in NIPS paper and at NIPS workshop talk. Updated release with correction to Hessian for non-linear response model and modular code for the MAP approximation. Removed update of kernel parameters 'Hessian correction'.

Version 0.1
-----------

A quick and dirty release for the results to be submitted to the GPIP workshop.
