function model = gpSubspaceExpandParam(model,params)

% GPSUBSPACEEXPANDPARAM 
%
% COPYRIGHT : Carl Henrik Ek, 2008

% GP
  
model = gpExpandParam(model,params);

return;
