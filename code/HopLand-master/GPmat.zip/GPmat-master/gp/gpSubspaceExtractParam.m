function params = gpSubspaceExtractParam(model)
  
% GPSUBSPACEEXTRACTPARAM
%
% COPYRIGHT : Carl Henrik Ek, 2008
  
% GP 
  
params = gpExtractParam(model);

return;
