Version 0.11
------------

Minor fix to demPlotMef2Models.m.

Version 0.1
-----------

First release. Used for results in PNAS paper.
