function g = robTwoDynamicsLogLikeGradients(model)

% ROBTWODYNAMICSLOGLIKEGRADIENTS Gradients of the robot two dynamics wrt parameters.

% FGPLVM

g = [];
