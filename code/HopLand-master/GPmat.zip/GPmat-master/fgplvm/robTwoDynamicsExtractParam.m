function param = robTwoDynamicsExtractParam(model)

% ROBTWODYNAMICSEXTRACTPARAM Extract parameters from the robot two dynamics model.

% FGPLVM

param = [];
