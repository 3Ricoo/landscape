function param = robThreeDynamicsExtractParam(model)

% ROBTHREEDYNAMICSEXTRACTPARAM Extract parameters from the robot three dynamics model.

% FGPLVM

param = [];
