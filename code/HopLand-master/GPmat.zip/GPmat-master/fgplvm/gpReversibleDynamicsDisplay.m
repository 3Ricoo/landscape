function gpReversibleDynamicsDisplay(model, varargin)

% GPREVERSIBLEDYNAMICSDISPLAY Display a GP dynamics model.

% FGPLVM

gpDisplay(model, varargin{:});
