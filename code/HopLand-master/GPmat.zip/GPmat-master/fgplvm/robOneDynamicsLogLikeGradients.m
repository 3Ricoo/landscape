function g = robOneDynamicsLogLikeGradients(model)

% ROBONEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot one dynamics wrt parameters.

% FGPLVM

g = [];
