function param = robOneDynamicsExtractParam(model)

% ROBONEDYNAMICSEXTRACTPARAM Extract parameters from the robot one dynamics model.

% FGPLVM

param = [];
