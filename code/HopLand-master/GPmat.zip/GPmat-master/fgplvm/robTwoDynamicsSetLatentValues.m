function model = robTwoDynamicsSetLatentValues(model, X)

% ROBTWODYNAMICSSETLATENTVALUES Set the latent values inside the model.

% FGPLVM

model = robOneDynamicsSetLatentValues(model, X);
