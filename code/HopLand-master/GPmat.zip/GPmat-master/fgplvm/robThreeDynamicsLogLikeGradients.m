function g = robThreeDynamicsLogLikeGradients(model)

% ROBTHREEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot three dynamics wrt parameters.

% FGPLVM

g = [];
